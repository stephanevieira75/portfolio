<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="fr" dir="ltr">
  <head>
    <title>Charte utilisateur</title>
    <style type="text/css">
      html, body, div, object, p {
        margin:0;
        padding:0;
        border:0;
        width:100%;
        height:100%;
      }
 
      object {
        display:block;
        width:100%;
        height:100%;
      }
   
    </style>
  </head>
  <body>
  <div>
      <object data="pdf/condition-utilisation.pdf" type="application/pdf">
       
      </object>
    </div>
  
  
    
  </body>
</html>